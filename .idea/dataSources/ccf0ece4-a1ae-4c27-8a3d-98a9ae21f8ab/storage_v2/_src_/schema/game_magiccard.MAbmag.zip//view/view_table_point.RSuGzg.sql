create view view_table_point as
select `game_magiccard`.`users`.`pointGame` AS `pointGame`
from `game_magiccard`.`users`
order by `game_magiccard`.`users`.`pointGame`;

